package ch4;

public class MultiplesOfTwo {
    public static void main(String[] args) {
        int number = 2;

        while (true) {
            System.out.println(number);
            number += 2;
        }
    }
}

